import SwiftUI
import SceneKit

/// Shared soldier model (vest, arms, legs, 3D firearms) used by the 5v5 scene.
struct TwSoldier {
    var root: SCNNode
    var legL: SCNNode
    var legR: SCNNode
    var holder: SCNNode
    var variants: [SCNNode]
    var flash: SCNNode
    var shirt: SCNMaterial
    var face: SCNNode
    var faceMat: SCNMaterial
    var kev: SCNNode
    var helm: SCNNode
    var heavy: SCNNode
    var hat: SCNNode
}

enum TwRig {
    static func col(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: min(1, r), green: min(1, g), blue: min(1, b), alpha: 1) }

    static func mat(_ c: UIColor, glow: Bool = false) -> SCNMaterial {
        let m = SCNMaterial()
        m.diffuse.contents = c
        if glow { m.emission.contents = c; m.lightingModel = .constant }
        return m
    }

    static func box(_ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ c: UIColor, glow: Bool = false) -> SCNNode {
        let g = SCNBox(width: w, height: h, length: l, chamferRadius: min(w, h, l) * 0.28)
        g.chamferSegmentCount = 2
        g.materials = [mat(c, glow: glow)]
        return SCNNode(geometry: g)
    }

    static func ball(_ r: CGFloat, _ c: UIColor) -> SCNNode {
        let g = SCNSphere(radius: r)
        g.segmentCount = 20
        g.materials = [mat(c)]
        return SCNNode(geometry: g)
    }

    static func cyl(_ r: CGFloat, _ h: CGFloat, _ c: UIColor) -> SCNNode {
        let g = SCNCylinder(radius: r, height: h)
        g.radialSegmentCount = 18
        g.materials = [mat(c)]
        return SCNNode(geometry: g)
    }

    static func cap(_ rad: CGFloat, _ h: CGFloat, _ c: UIColor) -> SCNNode {
        let g = SCNCapsule(capRadius: rad, height: max(h, rad * 2 + 0.1))
        g.radialSegmentCount = 20
        g.capSegmentCount = 8
        g.materials = [mat(c)]
        return SCNNode(geometry: g)
    }

    private static var camoCache: [String: SCNMaterial] = [:]
    static func camoMat(_ base: UIColor, _ key: String) -> SCNMaterial {
        if let m = camoCache[key] { return m }
        var br: CGFloat = 0, bg: CGFloat = 0, bb: CGFloat = 0, ba: CGFloat = 0
        base.getRed(&br, green: &bg, blue: &bb, alpha: &ba)
        let img = UIGraphicsImageRenderer(size: CGSize(width: 64, height: 64)).image { c in
            base.setFill(); c.cgContext.fill(CGRect(x: 0, y: 0, width: 64, height: 64))
            var seed: UInt64 = 99
            func nx() -> CGFloat { seed = seed &* 6364136223846793005 &+ 1442695040888963407; return CGFloat((seed >> 33) % 1000) / 1000 }
            for i in 0..<26 {
                let k: CGFloat = i % 2 == 0 ? 0.72 : 1.22
                UIColor(red: min(1, br * k), green: min(1, bg * k), blue: min(1, bb * k), alpha: 1).setFill()
                c.cgContext.fillEllipse(in: CGRect(x: nx() * 64, y: nx() * 64, width: 8 + nx() * 16, height: 5 + nx() * 10))
            }
        }
        let m = SCNMaterial()
        m.diffuse.contents = img
        m.diffuse.wrapS = .repeat; m.diffuse.wrapT = .repeat
        camoCache[key] = m
        return m
    }

    static func at(_ n: SCNNode, _ x: CGFloat, _ y: CGFloat, _ z: CGFloat) -> SCNNode {
        n.position = SCNVector3(Float(x), Float(y), Float(z))
        return n
    }

    static func gunIdx(_ id: String) -> Int { TWeapons.all.firstIndex { $0.id == id } ?? 0 }

    /// look: 0 = SWAT / standard, 1 = hooded anarchist, 2 = street (cap + chain), 3 = fur hat + camo.
    /// rank: 0 = fighter, 1 = staff (hi-vis vest, cap, lanyard), 2 = admin (black suit, tie, shades).
    static func soldier(shirt: UIColor, skin: UIColor, look: Int, rank: Int) -> TwSoldier {
        let root = SCNNode()
        let admin = rank == 2, staff = rank == 1
        let lk = ((look % 4) + 4) % 4

        // ---- clothing colours
        let pantsCol: UIColor
        if admin { pantsCol = col(0.07, 0.07, 0.09) }
        else if staff { pantsCol = col(0.1, 0.13, 0.22) }
        else { pantsCol = [col(0.5, 0.43, 0.3), col(0.16, 0.16, 0.18), col(0.2, 0.2, 0.3), col(0.34, 0.38, 0.24)][lk] }
        let pantsM: SCNMaterial = (admin || staff || lk == 1 || lk == 2) ? mat(pantsCol) : camoMat(pantsCol, "pants\(lk)")
        let top: UIColor = admin ? col(0.08, 0.08, 0.1) : (staff ? col(0.08, 0.45, 0.5) : shirt)
        let sleeveM: SCNMaterial = (admin || staff || lk == 1 || lk == 2) ? mat(top) : pantsM
        let vestC = col(0.36, 0.34, 0.26)
        let plateC = col(0.22, 0.23, 0.2)
        let bootC = admin ? col(0.04, 0.04, 0.05) : col(0.12, 0.09, 0.07)

        // ---- legs
        var legs: [SCNNode] = []
        for z in [-3.5, 3.5] as [CGFloat] {
            let hip = SCNNode()
            hip.position = SCNVector3(0, 16, Float(z))
            let th = cap(3.0, 15, pantsCol); th.geometry?.materials = [pantsM]
            hip.addChildNode(at(th, 0, -7.5, 0))
            if !admin && !staff { hip.addChildNode(at(cap(3.5, 5, col(0.2, 0.2, 0.17)), 0.6, -9, 0)) }
            let boot = ball(3, bootC); boot.scale = SCNVector3(1.7, 0.8, 1.05)
            hip.addChildNode(at(boot, 1.6, -14.4, 0))
            root.addChildNode(hip)
            legs.append(hip)
        }

        // ---- torso + shoulders
        let sm = SCNMaterial()
        sm.diffuse.contents = top
        let tg = SCNSphere(radius: 1)
        tg.segmentCount = 24
        tg.materials = [sm]
        let torso = SCNNode(geometry: tg)
        torso.scale = SCNVector3(4.6, 8.4, 7.4)
        root.addChildNode(at(torso, 0, 23.8, 0))
        for z in [-7.6, 7.6] as [CGFloat] { root.addChildNode(at(ball(3, top), 0, 29.4, z)) }
        root.addChildNode(at(box(8, 2, 14.5, admin ? col(0.04, 0.04, 0.05) : col(0.1, 0.1, 0.08)), 0, 17.6, 0))   // belt
        root.addChildNode(at(cyl(2.6, 3, skin), 0.2, 31.6, 0))

        // ---- role clothing
        if admin {
            root.addChildNode(at(box(0.9, 5.6, 3.8, col(0.95, 0.95, 0.97)), 4.72, 26.6, 0))                 // shirt
            root.addChildNode(at(box(0.7, 6.2, 1.1, col(0.8, 0.08, 0.1)), 5.12, 26.2, 0))                  // tie
            for s in [-1.0, 1.0] as [CGFloat] {
                let lap = box(0.8, 6.8, 2.4, col(0.05, 0.05, 0.07))
                lap.eulerAngles = SCNVector3(Float(s) * 0.0, Float(s) * 0.4, 0)
                root.addChildNode(at(lap, 4.9, 26.4, s * 3.0))
            }
            root.addChildNode(at(box(0.5, 1.0, 1.0, col(1, 0.82, 0.25), glow: true), 5.15, 28.6, 3.6))       // gold pin
            root.addChildNode(at(box(5.2, 0.7, 14.8, col(0.04, 0.04, 0.05)), 0, 20.2, 0))                    // jacket hem
        } else if staff {
            let hv = col(0.82, 0.96, 0.12)
            root.addChildNode(at(box(9.6, 8.6, 15.2, hv), 0, 25.6, 0))
            root.addChildNode(at(box(9.8, 0.9, 15.4, col(0.88, 0.88, 0.92)), 0, 23.6, 0))
            root.addChildNode(at(box(9.8, 0.9, 15.4, col(0.88, 0.88, 0.92)), 0, 27.6, 0))
            root.addChildNode(at(box(0.4, 5.6, 0.7, col(1, 1, 1)), 5.1, 26.2, 1.4))                          // lanyard
            root.addChildNode(at(box(0.5, 2.8, 2.0, col(0.95, 0.95, 1)), 5.25, 22.6, 1.4))                   // badge
            root.addChildNode(at(box(0.3, 0.8, 1.6, col(0.1, 0.55, 0.6)), 5.55, 23.4, 1.4))
        } else if lk == 2 {
            for k in 0..<5 {
                root.addChildNode(at(ball(0.55, col(1, 0.82, 0.25)), 4.9 + CGFloat(k % 2) * 0.1, 27.6 - CGFloat(abs(k - 2)) * 0.9, CGFloat(k - 2) * 1.3))
            }
        }

        // ---- armor layers (toggled from the scene by the player's armor state)
        let kev = SCNNode()
        kev.addChildNode(at(box(9.8, 5, 15.4, vestC), 0, 28, 0))
        for z in [-4.0, 0.0, 4.0] as [CGFloat] { kev.addChildNode(at(box(2, 2.2, 3.4, col(0.3, 0.28, 0.2)), 5.6, 23.4, z)) }
        kev.addChildNode(at(box(1, 8, 9.5, plateC), 5, 26, 0))
        kev.addChildNode(at(box(1, 8, 9.5, plateC), -5, 26, 0))
        for z in [-3.4, 3.4] as [CGFloat] { kev.addChildNode(at(box(2.6, 3.6, 3.6, col(0.15, 0.17, 0.13)), 5.4, 20.4, z)) }
        kev.addChildNode(at(ball(3.2, vestC), 0, 30.4, -7.6))
        kev.addChildNode(at(ball(3.2, vestC), 0, 30.4, 7.6))
        kev.addChildNode(at(cyl(3.6, 3.2, col(0.78, 0.68, 0.5)), 0.2, 31.2, 0))
        kev.addChildNode(at(box(4, 12, 9, col(0.24, 0.26, 0.2)), -6.2, 24, 0))
        kev.addChildNode(at(box(2.4, 2.4, 14, col(0.12, 0.12, 0.1)), 1.2, 21.2, 0))
        kev.isHidden = true
        root.addChildNode(kev)

        let heavy = SCNNode()
        for z in [-9.2, 9.2] as [CGFloat] { heavy.addChildNode(at(box(3.4, 3.6, 4.8, col(0.14, 0.15, 0.17)), 0, 32, z)) }
        heavy.addChildNode(at(box(1.6, 10.5, 11.5, col(0.12, 0.13, 0.15)), 5.9, 26, 0))
        heavy.addChildNode(at(box(2, 4.2, 6.6, col(0.14, 0.15, 0.17)), 5.4, 16.6, 0))
        heavy.addChildNode(at(box(0.5, 0.9, 10, col(1, 0.75, 0.2), glow: true), 6.8, 30, 0))
        heavy.addChildNode(at(box(0.5, 0.9, 10, col(1, 0.75, 0.2), glow: true), 6.8, 22.4, 0))
        heavy.isHidden = true
        root.addChildNode(heavy)

        // ---- head
        let head = ball(4.6, skin); head.scale = SCNVector3(0.95, 1.12, 0.92)
        root.addChildNode(at(head, 0.4, 35.5, 0))
        if admin {
            root.addChildNode(at(box(1.2, 1.7, 8.8, col(0.02, 0.02, 0.03)), 4.8, 36.2, 0))                  // shades
            root.addChildNode(at(box(0.5, 0.5, 3.6, col(0.5, 0.65, 0.85), glow: true), 5.4, 36.5, 0))
        } else if lk == 1 && !staff {
            root.addChildNode(at(box(1.3, 2.4, 8.2, col(0.78, 0.1, 0.1)), 4.3, 33.6, 0))                    // bandana
            root.addChildNode(at(box(1.2, 1.2, 8.4, col(0.04, 0.04, 0.05)), 4.8, 36.4, 0))
        }

        let hat = SCNNode()
        if admin {
            let hair = ball(4.9, col(0.05, 0.04, 0.04)); hair.scale = SCNVector3(0.98, 0.6, 0.95)
            hat.addChildNode(at(hair, 0.1, 38.4, 0))
        } else if staff {
            let c = ball(5, col(0.1, 0.14, 0.3)); c.scale = SCNVector3(1, 0.55, 1)
            hat.addChildNode(at(c, 0.2, 38.2, 0))
            hat.addChildNode(at(box(3.8, 0.5, 7.8, col(0.08, 0.1, 0.24)), 5.4, 37.4, 0))
            hat.addChildNode(at(box(0.4, 1.5, 1.7, col(1, 0.82, 0.25), glow: true), 5.0, 38.4, 0))
        } else if lk == 0 {
            let b = ball(5, col(0.08, 0.08, 0.09)); b.scale = SCNVector3(1, 0.62, 1)
            hat.addChildNode(at(b, 0.2, 38, 0))
        } else if lk == 1 {
            let h = ball(5.4, col(0.2, 0.2, 0.22)); h.scale = SCNVector3(1, 0.85, 1.05)
            hat.addChildNode(at(h, -0.2, 37.2, 0))
        } else if lk == 2 {
            let c = ball(5, col(0.36, 0.2, 0.5)); c.scale = SCNVector3(1, 0.5, 1)
            hat.addChildNode(at(c, 0.2, 38.2, 0))
            hat.addChildNode(at(box(3.6, 0.5, 7.4, col(0.3, 0.16, 0.42)), 5.2, 37.4, 0))
        } else {
            let f = cyl(5.2, 3.4, col(0.42, 0.38, 0.32))
            hat.addChildNode(at(f, 0.1, 38.4, 0))
            hat.addChildNode(at(box(1, 3.2, 3.2, col(0.36, 0.32, 0.27)), 0.1, 36.8, -5.6))
            hat.addChildNode(at(box(1, 3.2, 3.2, col(0.36, 0.32, 0.27)), 0.1, 36.8, 5.6))
        }
        root.addChildNode(hat)

        let helm = SCNNode()
        helm.addChildNode(at(box(1.2, 1.6, 8.6, col(0.04, 0.04, 0.05)), 4.7, 36.2, 0))
        helm.addChildNode(at(box(0.8, 1, 8, col(0.35, 0.65, 0.9), glow: true), 5.1, 36.2, 0))
        let helmet = ball(5.2, col(0.3, 0.32, 0.24)); helmet.geometry?.materials = [camoMat(col(0.42, 0.4, 0.28), "helm")]
        helmet.scale = SCNVector3(1, 0.72, 1)
        helm.addChildNode(at(helmet, 0.2, 37.6, 0))
        helm.addChildNode(at(box(2.4, 1.4, 7.5, col(0.05, 0.05, 0.07)), 4.1, 36, 0))
        helm.isHidden = true
        root.addChildNode(helm)

        // ---- arms
        let rArm = cap(2.0, 12, col(0.3, 0.3, 0.22)); rArm.geometry?.materials = [sleeveM]
        rArm.eulerAngles = SCNVector3(0, -0.2, Float.pi / 2 - 0.1)
        root.addChildNode(at(rArm, 6.5, 26.5, 6))
        let handC: UIColor = (admin) ? col(0.92, 0.92, 0.94) : skin
        root.addChildNode(at(ball(1.9, handC), 12.2, 26, 4.8))
        let lArm = cap(2.0, 16, col(0.3, 0.3, 0.22)); lArm.geometry?.materials = [sleeveM]
        lArm.eulerAngles = SCNVector3(0, 0.35, Float.pi / 2 - 0.08)
        root.addChildNode(at(lArm, 8.2, 26.5, -4.6))
        root.addChildNode(at(ball(1.9, handC), 15.5, 26, -1.4))

        // ---- weapon: one detailed model per gun id
        let holder = SCNNode()
        holder.position = SCNVector3(10, 26.5, 1.8)
        var variants: [SCNNode] = []
        for (k, w) in TWeapons.all.enumerated() {
            let gm = TwGunLib.worldGun(w.id)
            gm.isHidden = k != 0
            holder.addChildNode(gm)
            variants.append(gm)
        }
        let fl = box(6, 5, 5, col(1, 0.85, 0.3), glow: true)
        fl.position = SCNVector3(TwGunLib.muzzleX(TWeapons.all[0].id) + 1, 1, 0)
        fl.isHidden = true
        holder.addChildNode(fl)
        root.addChildNode(holder)

        // avatar badge on top of the head (readable from above)
        let faceMat = SCNMaterial()
        faceMat.lightingModel = .constant
        faceMat.isDoubleSided = true
        faceMat.diffuse.contents = UIColor.gray
        let fp = SCNPlane(width: 14, height: 14)
        fp.materials = [faceMat]
        let pn = SCNNode(geometry: fp)
        pn.eulerAngles = SCNVector3(-Float.pi / 2, 0, 0)
        let face = SCNNode()
        face.position = SCNVector3(0.2, 42.6, 0)
        face.addChildNode(pn)
        face.isHidden = true
        root.addChildNode(face)
        root.scale = SCNVector3(1.25, 1.25, 1.25)
        return TwSoldier(root: root, legL: legs[0], legR: legs[1], holder: holder, variants: variants, flash: fl, shirt: sm, face: face, faceMat: faceMat, kev: kev, helm: helm, heavy: heavy, hat: hat)
    }
}

enum TGuns {
    static func get(_ id: String) -> GunDef {
        let w = TWeapons.w(id)
        return GunDef(id: w.id, name: w.name, emoji: "", dmg: w.dmg, rate: 1 / w.interval, mag: w.mag, reload: w.reload, spread: w.spread, pellets: w.pellets, speed: 1100, range: w.range, price: w.price)
    }
}
